export interface IBook
{
    authors:string[],
    title:string,
    url:string,
    publisher:string,
    publishedDate:string,
    description:string,
    thumbnail:string
  }